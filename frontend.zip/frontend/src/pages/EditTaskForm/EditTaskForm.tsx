// Edit Task Form

import Header from "../../components/Header/Header";

const EditTaskForm = () => {
    return (
        <>
            <Header/>
            <h1>Edit Task</h1>
        </>
    );
}

export default EditTaskForm;